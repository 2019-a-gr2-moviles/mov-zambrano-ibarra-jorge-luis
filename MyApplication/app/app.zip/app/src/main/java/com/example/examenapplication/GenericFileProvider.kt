package com.example.examenapplication

import android.support.v4.content.FileProvider

class GenericFileProvider : FileProvider() {

}