package com.example.examenapplication

class BDD{
    companion object {
        val equipo = ArrayList<EquipoHttp>()
        val jugador = ArrayList<JugadorHTTP>()
        val usuario = ArrayList<UsuarioHttp>()
    }
}