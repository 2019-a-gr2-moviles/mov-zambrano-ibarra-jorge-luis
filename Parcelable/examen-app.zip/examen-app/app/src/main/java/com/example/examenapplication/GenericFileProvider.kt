package com.example.examenapplication

import androidx.core.content.FileProvider

class GenericFileProvider : FileProvider() {

}